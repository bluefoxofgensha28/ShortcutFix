# ShortcutFix test checklist

## On emulator and physical Galaxy A06 4G
- [ ] App starts without crashing.
- [ ] Launcher-visible app list populates and is alphabetically sorted.
- [ ] Search matches app labels and package names.
- [ ] Open launches a selected app or reports a failure.
- [ ] Request shortcut with a valid label; record whether One UI displays a prompt and whether an icon appears.
- [ ] Cancel a shortcut request and confirm the app does not claim success.
- [ ] Test when pinned shortcuts are unsupported.
- [ ] Uninstall a target app after listing and confirm launch/request failures are handled.
- [ ] Test offline; core features should not require a network.
- [ ] Review manifest and logs for unnecessary permissions or sensitive data.
- [ ] Repeat tests after device restart and after app updates.

## Release gate
Do not label the app production-ready until a successful Gradle build, unit tests, lint, signed release artifact checks, and physical-device QA have been completed.
