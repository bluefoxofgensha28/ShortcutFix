package com.shortcutfix.app

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LabelValidationTest {
    @Test fun blankLabelsAreRejectedByTrimRule() {
        assertTrue("   ".isBlank())
    }

    @Test fun nonBlankLabelsAreAcceptedByTrimRule() {
        assertFalse("Chrome".isBlank())
    }

    @Test fun labelsCanBeLimitedToFortyCharacters() {
        val longLabel = "x".repeat(60)
        assertTrue(longLabel.take(40).length == 40)
    }
}
