package com.shortcutfix.app

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

class AppRepository(private val context: Context) {
    private val packageManager: PackageManager = context.packageManager

    @Suppress("DEPRECATION")
    fun getLaunchableApps(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val results = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.queryIntentActivities(
                intent,
                PackageManager.ResolveInfoFlags.of(0L)
            )
        } else {
            packageManager.queryIntentActivities(intent, 0)
        }

        return results.mapNotNull { resolveInfo ->
            val activityInfo = resolveInfo.activityInfo ?: return@mapNotNull null
            val packageName = activityInfo.packageName
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
                ?: return@mapNotNull null
            val label = resolveInfo.loadLabel(packageManager)?.toString()
                ?.takeIf { it.isNotBlank() } ?: packageName
            InstalledApp(
                label = label,
                packageName = packageName,
                icon = resolveInfo.loadIcon(packageManager)
            )
        }.distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun getLaunchIntent(packageName: String): Intent? =
        packageManager.getLaunchIntentForPackage(packageName)
}
