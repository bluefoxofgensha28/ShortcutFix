package com.shortcutfix.app

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Canvas
import android.graphics.Bitmap

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortcutFixScreen() {
    val context = LocalContext.current
    val repository = remember { AppRepository(context) }
    val shortcutService = remember { ShortcutService(context) }
    var apps by remember { mutableStateOf(emptyList<InstalledApp>()) }
    var search by remember { mutableStateOf("") }
    var selectedApp by remember { mutableStateOf<InstalledApp?>(null) }
    var shortcutLabel by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Ready. App inventory is read from Android.") }
    var selectedTab by remember { mutableStateOf("Apps") }
    val events = remember { mutableStateListOf("ShortcutFix started") }

    fun refreshApps() {
        apps = try {
            repository.getLaunchableApps()
        } catch (e: Exception) {
            message = "Could not read the app list: ${e.message ?: "platform error"}"
            emptyList()
        }
    }

    LaunchedEffect(Unit) { refreshApps() }

    val filteredApps = apps.filter {
        it.label.contains(search, ignoreCase = true) ||
            it.packageName.contains(search, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("ShortcutFix", fontWeight = FontWeight.Bold)
                        Text("QUICKINSTALL HELPER", fontSize = 10.sp, color = Color.Gray)
                    }
                },
                actions = {
                    IconButton(onClick = { selectedTab = if (selectedTab == "Apps") "Diagnostics" else "Apps" }) {
                        Icon(Icons.Default.Settings, contentDescription = "Switch view")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF5EF)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Make every app easy to reach.", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Color(0xFF175C43))
                    Text("Native Android build · offline-first · no root required", fontSize = 12.sp, color = Color(0xFF426C59))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF197858), modifier = Modifier.size(16.dp))
                        Text("  ${apps.size} launchable apps discovered", fontSize = 12.sp)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { selectedTab = "Apps" }) { Icon(Icons.Default.Apps, null); Spacer(Modifier.size(6.dp)); Text("Installed apps") }
                OutlinedButton(onClick = { selectedTab = "Diagnostics" }) { Text("Diagnostics") }
            }

            if (selectedTab == "Apps") {
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    label = { Text("Search apps or package names") }
                )
                if (apps.isEmpty()) {
                    Text("No launchable apps found. Check Android app visibility settings.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    AppIcon(app.icon, Modifier.size(42.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(app.label, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(app.packageName, fontSize = 10.sp, color = Color.Gray)
                                    }
                                    OutlinedButton(onClick = {
                                        val launchIntent = repository.getLaunchIntent(app.packageName)
                                        if (launchIntent == null) {
                                            message = "No launch activity found for ${app.label}."
                                        } else {
                                            try {
                                                context.startActivity(launchIntent)
                                                message = "Launch intent sent for ${app.label}."
                                                events.add(0, "Launch requested: ${app.label}")
                                            } catch (e: Exception) {
                                                message = "Could not launch ${app.label}: ${e.message ?: "platform error"}"
                                                events.add(0, "Launch failed: ${app.label}")
                                            }
                                        }
                                    }) { Text("Open", fontSize = 11.sp) }
                                    IconButton(onClick = {
                                        selectedApp = app
                                        shortcutLabel = app.label
                                    }) { Icon(Icons.Default.Add, contentDescription = "Create shortcut") }
                                }
                            }
                        }
                    }
                }
            } else {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Diagnostics", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(message, fontSize = 13.sp)
                        Text("Recent local events", fontWeight = FontWeight.SemiBold)
                        if (events.isEmpty()) Text("No events yet.")
                        events.take(8).forEach { Text("• $it", fontSize = 12.sp, color = Color.DarkGray) }
                        Divider()
                        Text("If an icon is missing, first search the app drawer and confirm the app is installed. A missing icon does not prove app data is damaged.", fontSize = 12.sp)
                        Text("ShortcutFix does not edit protected launcher databases or other apps' private data.", fontSize = 12.sp, color = Color(0xFF197858))
                    }
                }
                Spacer(Modifier.weight(1f))
            }

            Text(message, fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 8.dp))
        }
    }

    if (selectedApp != null) {
        AlertDialog(
            onDismissRequest = { selectedApp = null },
            title = { Text("Create home-screen shortcut") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("App: ${selectedApp?.label}")
                    OutlinedTextField(
                        value = shortcutLabel,
                        onValueChange = { shortcutLabel = it.take(40) },
                        label = { Text("Shortcut name") },
                        singleLine = true
                    )
                    Text("Android or the launcher may ask for confirmation. Placement cannot be guaranteed.", fontSize = 12.sp, color = Color.Gray)
                }
            },
            confirmButton = {
                Button(onClick = {
                    val app = selectedApp
                    if (app == null) {
                        message = "Choose an app first."
                    } else if (shortcutLabel.isBlank()) {
                        message = "Enter a shortcut name."
                    } else {
                        val intent = repository.getLaunchIntent(app.packageName)
                        message = if (intent == null) {
                            "No launch activity found for ${app.label}."
                        } else {
                            when (val result = shortcutService.requestPinnedShortcut(app.packageName, shortcutLabel, intent)) {
                                ShortcutRequestResult.Requested -> {
                                    events.add(0, "Shortcut request accepted: ${app.label}")
                                    "Android accepted the shortcut request for ${app.label}. Check the launcher for confirmation."
                                }
                                ShortcutRequestResult.Unsupported -> "This launcher does not support pinned shortcut requests, or declined the request."
                                ShortcutRequestResult.TargetUnavailable -> "The target app is no longer available."
                                is ShortcutRequestResult.Failed -> "Shortcut request failed: ${result.message}"
                            }
                        }
                        selectedApp = null
                    }
                }) { Text("Request shortcut") }
            },
            dismissButton = { OutlinedButton(onClick = { selectedApp = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun AppIcon(drawable: android.graphics.drawable.Drawable, modifier: Modifier = Modifier) {
    val bitmap = remember(drawable) {
        val width = 96
        val height = 96
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        drawable.setBounds(0, 0, width, height)
        drawable.draw(canvas)
        bmp.asImageBitmap()
    }
    Image(bitmap = bitmap, contentDescription = null, modifier = modifier)
}
