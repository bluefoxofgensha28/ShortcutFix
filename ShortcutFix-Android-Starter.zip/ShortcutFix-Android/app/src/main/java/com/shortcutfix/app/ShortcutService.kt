package com.shortcutfix.app

import android.content.Context
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.os.Build
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

sealed interface ShortcutRequestResult {
    data object Requested : ShortcutRequestResult
    data object Unsupported : ShortcutRequestResult
    data object TargetUnavailable : ShortcutRequestResult
    data class Failed(val message: String) : ShortcutRequestResult
}

class ShortcutService(private val context: Context) {
    fun requestPinnedShortcut(
        packageName: String,
        label: String,
        launchIntent: android.content.Intent
    ): ShortcutRequestResult {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
            return ShortcutRequestResult.Unsupported
        }
        if (label.isBlank()) {
            return ShortcutRequestResult.Failed("Enter a shortcut name.")
        }

        return try {
            val shortcut = ShortcutInfoCompat.Builder(
                context,
                "shortcutfix_${packageName.hashCode()}_${label.hashCode()}"
            )
                .setShortLabel(label.trim().take(40))
                .setLongLabel(label.trim().take(80))
                .setIntent(launchIntent)
                .setIcon(IconCompat.createWithResource(context, R.drawable.ic_shortcutfix))
                .build()

            val accepted = ShortcutManagerCompat.requestPinShortcut(context, shortcut, null)
            if (accepted) ShortcutRequestResult.Requested else ShortcutRequestResult.Unsupported
        } catch (e: Exception) {
            ShortcutRequestResult.Failed(e.message ?: "Android could not process the shortcut request.")
        }
    }
}
