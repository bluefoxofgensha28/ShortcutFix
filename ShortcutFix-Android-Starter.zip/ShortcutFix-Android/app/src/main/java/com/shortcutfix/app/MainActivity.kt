package com.shortcutfix.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(245, 247, 246)
        window.navigationBarColor = android.graphics.Color.rgb(245, 247, 246)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF197858),
                    secondary = Color(0xFF398C6B),
                    background = Color(0xFFF5F7F6),
                    surface = Color(0xFFFFFFFF)
                )
            ) {
                ShortcutFixScreen()
            }
        }
    }
}
