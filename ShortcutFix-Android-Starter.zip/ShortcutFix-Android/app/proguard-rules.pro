# Keep project-specific rules here if shrinking is enabled for release builds.
