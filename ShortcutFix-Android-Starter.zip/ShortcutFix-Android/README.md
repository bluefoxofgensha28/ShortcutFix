# ShortcutFix — Native Android MVP

ShortcutFix is a native Kotlin + Jetpack Compose starter for Samsung Galaxy A06 4G first. It uses Android's public APIs to discover launchable apps, open apps, and request pinned shortcuts where supported.

## Current implementation

- Reads launchable activities through `PackageManager` with a targeted `<queries>` declaration.
- Searches the discovered app list.
- Launches apps through their package launch intents.
- Requests pinned shortcuts through AndroidX `ShortcutManagerCompat`.
- Shows local diagnostics and does not upload app inventory.
- Uses no root, Shizuku, accessibility service, backend, or broad storage permission.

## Important limitations

- This is starter source code, not a verified release build. It has not yet been compiled in this environment or tested on a physical Samsung Galaxy A06 4G.
- Android/One UI and third-party launchers decide whether to accept and display pinned shortcuts. A successful request is not proof that an icon is present on the home screen.
- The targeted package-visibility query is intentionally narrow. Test the inventory on the target OS/launcher and adjust only if a demonstrated visibility requirement and current Play policy justify it.
- Reinstalling apps or editing launcher databases is not part of this MVP.
- Play Store approval is not guaranteed.

## Build with Android Studio

1. Install Android Studio with a compatible Android SDK and JDK 17.
2. Open this folder as a Gradle project.
3. Let Android Studio sync Gradle and install any requested SDK components.
4. Run the `app` configuration on a test device.
5. Test discovery, opening apps, shortcut prompts, cancellation, and unsupported launcher behavior on the Galaxy A06 4G.
6. Before public release, review SDK/Gradle versions against the current Android Studio stable channel and Play target-API requirements.

## Build from a terminal

This archive does not include a Gradle wrapper binary. With Gradle installed and Android SDK configured:

```bash
gradle assembleDebug
gradle testDebugUnitTest
gradle lintDebug
```

Expected debug APK location after a successful build:

`app/build/outputs/apk/debug/app-debug.apk`

## Distribution

- Use a signed APK for direct installation.
- Use an Android App Bundle (AAB) for Google Play.
- Configure a release signing key securely; never commit it to Git.
- Keep the same application ID and signing identity for upgrade compatibility.
- Publish an accurate privacy policy and Data Safety declarations matching the actual shipped code.
